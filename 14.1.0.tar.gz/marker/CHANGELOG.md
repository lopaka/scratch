marker Cookbook CHANGELOG
=======================

This file is used to list changes made in each version of the marker cookbook.

v1.0.1
------

- Update README.md
- Use test-kitchen 1.1.1 on integration testing
- Added slack notification to .travis.yml
- Update .kitchen.yml with latest version OSs

v1.0.0
------

- Initial release
